// 🏴‍☠️ User Management Plugin - Routes
const express = require('express');
const router = express.Router();
const KeycloakManager = require('../../keycloak-integration');
const keycloak = new KeycloakManager();

// Create new user
router.post('/create', async (req, res) => {
    const { username, email, firstName, lastName, password, roles } = req.body;
    
    if (!username || !email || !firstName || !lastName || !password) {
        return res.status(400).json({ 
            success: false, 
            error: 'Missing required fields' 
        });
    }
    
    try {
        const keycloakResult = await keycloak.createUser({
            username,
            email,
            firstName,
            lastName,
            password,
            roles: roles || ['user']
        });
        
        if (!keycloakResult.success) {
            throw new Error(keycloakResult.error);
        }
        
        console.log(`✓ User created: ${username}`);
        
        res.json({
            success: true,
            message: 'User created successfully',
            user: {
                username,
                email,
                keycloakId: keycloakResult.userId
            }
        });
        
    } catch (error) {
        console.error('✗ User creation failed:', error.message);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// List all users
router.get('/', async (req, res) => {
    try {
        const users = await keycloak.listUsers();
        res.json({
            success: true,
            users: users.map(u => ({
                id: u.id,
                username: u.username,
                email: u.email,
                firstName: u.firstName,
                lastName: u.lastName,
                enabled: u.enabled,
                roles: u.roles || []
            }))
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Delete user
router.delete('/:id', async (req, res) => {
    try {
        const result = await keycloak.deleteUser(req.params.id);
        res.json(result);
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

module.exports = router;

// Update user
router.put('/:id', async (req, res) => {
    const { id } = req.params;
    const { firstName, lastName, email, enabled, roles } = req.body;
    
    try {
        const result = await keycloak.updateUser(id, {
            firstName,
            lastName,
            email,
            enabled,
            roles
        });
        res.json(result);
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Reset password
router.post('/:id/reset-password', async (req, res) => {
    const { id } = req.params;
    const { password } = req.body;
    
    if (!password) {
        return res.status(400).json({
            success: false,
            error: 'Password required'
        });
    }
    
    try {
        const result = await keycloak.resetPassword(id, password);
        res.json(result);
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Toggle user enabled/disabled
router.post('/:id/toggle', async (req, res) => {
    const { id } = req.params;
    
    try {
        const result = await keycloak.toggleUserStatus(id);
        res.json(result);
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});
