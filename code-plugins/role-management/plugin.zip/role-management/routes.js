// 🏴‍☠️ Role Management Plugin - Routes
const express = require('express');
const router = express.Router();
const KeycloakManager = require('../../keycloak-integration');
const keycloak = new KeycloakManager();

// List all roles
router.get('/', async (req, res) => {
    try {
        const roles = await keycloak.listRoles();
        res.json({
            success: true,
            roles
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Create custom role
router.post('/create', async (req, res) => {
    const { name, description, permissions, permissionMode } = req.body;
    
    if (!name) {
        return res.status(400).json({
            success: false,
            error: 'Role name is required'
        });
    }
    
    try {
        const result = await keycloak.createRole({ 
            name, 
            description,
            permissions: permissions || [],
            permissionMode: permissionMode || 'simple'
        });
        res.json(result);
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Delete role
router.delete('/:name', async (req, res) => {
    try {
        const roleName = decodeURIComponent(req.params.name);
        const result = await keycloak.deleteRole(roleName);
        res.json(result);
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

module.exports = router;
