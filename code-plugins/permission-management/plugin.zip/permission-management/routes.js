// 🏴‍☠️ Permission Management Plugin - Routes
const express = require('express');
const router = express.Router();
const KeycloakManager = require('../../keycloak-integration');
const keycloak = new KeycloakManager();

// List all custom permissions (stored as roles with 'permission:' prefix)
router.get('/', async (req, res) => {
    try {
        await keycloak.authenticate();
        const roles = await keycloak.kcAdminClient.roles.find({ realm: keycloak.realm });
        
        // Filter for custom permissions
        const permissions = roles
            .filter(role => role.name.startsWith('permission:'))
            .map(role => ({
                key: role.name.replace('permission:', ''),
                name: role.description || role.name.replace('permission:', '').replace(/-/g, ' '),
                description: role.attributes?.description?.[0] || ''
            }));
        
        res.json({ success: true, permissions });
    } catch (error) {
        console.error('Error fetching permissions:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Create custom permission
router.post('/create', async (req, res) => {
    try {
        const { key, name, description } = req.body;
        
        if (!key) {
            return res.status(400).json({ success: false, error: 'Permission key is required' });
        }
        
        // Validate key format
        if (!/^[a-z0-9-]+$/.test(key.trim())) {
            return res.status(400).json({ 
                success: false, 
                error: 'Permission key must be lowercase letters, numbers, and hyphens only' 
            });
        }
        
        await keycloak.authenticate();
        
        // Create as Keycloak role with 'permission:' prefix
        await keycloak.kcAdminClient.roles.create({
            realm: keycloak.realm,
            name: `permission:${key.trim()}`,
            description: name || key.replace(/-/g, ' '),
            attributes: {
                description: [description || ''],
                type: ['permission']
            }
        });
        
        res.json({ success: true, message: 'Permission created successfully' });
    } catch (error) {
        console.error('Error creating permission:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Delete permission
router.delete('/:key', async (req, res) => {
    try {
        const key = decodeURIComponent(req.params.key).trim();
        await keycloak.authenticate();
        
        await keycloak.kcAdminClient.roles.delByName({
            realm: keycloak.realm,
            name: `permission:${key}`
        });
        
        res.json({ success: true, message: 'Permission deleted successfully' });
    } catch (error) {
        console.error('Error deleting permission:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

module.exports = router;
