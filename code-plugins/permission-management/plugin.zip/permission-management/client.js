// Permission Management Plugin - Client-side JavaScript

// Show/hide create permission form
function showCreatePermissionForm() {
    document.getElementById('create-permission-card').style.display = 'block';
}

function hideCreatePermissionForm() {
    document.getElementById('create-permission-card').style.display = 'none';
    document.getElementById('create-permission-form').reset();
    document.getElementById('permission-creation-status').innerHTML = '';
}

// Load permissions
async function loadPermissions() {
    try {
        const response = await fetch('/plugins/permission-management');
        const result = await response.json();
        const permissionsList = document.getElementById('permissions-list');
        
        if (result.success && result.permissions.length > 0) {
            permissionsList.innerHTML = `
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 15px;">
                    ${result.permissions.map(perm => `
                        <div style="background: #1a1a1a; border: 1px solid #333; border-radius: 8px; padding: 20px;">
                            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 10px;">
                                <div>
                                    <h4 style="margin: 0; color: #667eea; font-size: 16px;">${perm.name}</h4>
                                    <span style="font-size: 12px; color: #666; font-family: monospace;">${perm.key}</span>
                                </div>
                                <button onclick="deletePermission('${perm.key}')" 
                                        style="padding: 6px 12px; background: #4a1a1a; color: #f87171; border: none; border-radius: 4px; cursor: pointer; font-size: 12px;">
                                    Delete
                                </button>
                            </div>
                            <p style="color: #aaa; font-size: 13px; margin: 0;">${perm.description || 'No description'}</p>
                        </div>
                    `).join('')}
                </div>
            `;
        } else {
            permissionsList.innerHTML = `
                <div style="text-align: center; padding: 40px; color: #666;">
                    <p style="font-size: 16px; margin-bottom: 10px;">No custom permissions yet</p>
                    <p style="font-size: 13px;">Click "+ Create Permission" to add your first permission</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('Error loading permissions:', error);
        document.getElementById('permissions-list').innerHTML = 
            '<p style="color: #f87171;">Error loading permissions.</p>';
    }
}

// Delete permission
async function deletePermission(key) {
    if (!confirm(`Delete permission "${key}"?`)) {
        return;
    }
    
    try {
        const response = await fetch(`/plugins/permission-management/${encodeURIComponent(key)}`, { 
            method: 'DELETE' 
        });
        const result = await response.json();
        if (result.success) {
            alert('✓ Permission deleted successfully!');
            await loadPermissions();
        } else {
            alert(`Error: ${result.error}`);
        }
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
}

// Handle permission creation form
const permForm = document.getElementById('create-permission-form');
if (permForm) {
    permForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const permData = {
            key: formData.get('key'),
            name: formData.get('name'),
            description: formData.get('description')
        };
        
        const statusDiv = document.getElementById('permission-creation-status');
        statusDiv.innerHTML = '<p style="color: #667eea;">Creating permission...</p>';
        
        try {
            const response = await fetch('/plugins/permission-management/create', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(permData)
            });
            const result = await response.json();
            
            if (result.success) {
                statusDiv.innerHTML = `
                    <div style="padding: 15px; background: #1a472a; border: 1px solid #4ade80; border-radius: 6px; color: #4ade80;">
                        ✓ Permission created successfully!
                    </div>
                `;
                setTimeout(() => {
                    hideCreatePermissionForm();
                    loadPermissions();
                }, 1500);
            } else {
                statusDiv.innerHTML = `
                    <div style="padding: 15px; background: #4a1a1a; border: 1px solid #f87171; border-radius: 6px; color: #f87171;">
                        ✗ Error: ${result.error}
                    </div>
                `;
            }
        } catch (error) {
            statusDiv.innerHTML = `
                <div style="padding: 15px; background: #4a1a1a; border: 1px solid #f87171; border-radius: 6px; color: #f87171;">
                    ✗ Error: ${error.message}
                </div>
            `;
        }
    });
}

// Initialize: load permissions when view loads
loadPermissions();
